package _11_generic_stack_queue;

public class DemoGeneric {

    public static <Z> void printElement(Z[] object){
        for(int index = 0;  index< object.length; index++){
            System.out.print(object[index] + "\t");
        }
    }
    public static void main(String[] args) {
        Integer[] intArr = {1,2,3};
        Double[] doublesArr = {1.0,2.2,3.3};
        String[] stringArr = {"one","two","three"};

        printElement(intArr);
        printElement(doublesArr);
        printElement(stringArr);
    }
}
