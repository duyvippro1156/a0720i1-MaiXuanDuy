package _11_generic_stack_queue;

public class MyMap<K, V> {
    private K key;
    private V value;

    public MyMap(K key, V value) {
        this.key = key;
        this.value = value;
    }

    public MyMap() {
    }

    public K getKey() {
        return key;
    }

    public void setKey(K key) {
        this.key = key;
    }

    public V getValue() {
        return value;
    }

    public void setValue(V value) {
        this.value = value;
    }

    public static void main(String[] args) {
        MyMap<String, Integer> myMap = new MyMap("one", 1);
        MyMap<Double, String> myMap1 = new MyMap(2.2, "abc");
        System.out.println("Key: "+ myMap.getKey() +" Value: "+myMap.getValue());
        System.out.println("Key: "+ myMap1.getKey() +" Value: "+myMap1.getValue());
    }
}
