package _11_generic_stack_queue;

import java.util.ArrayList;
import java.util.List;

public class Demo2{
    public static void printElement(List<? extends Object> object){
        for(int index = 0;  index< object.size(); index++){
            System.out.print(object.get(index) + "\t");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        List<Integer> intList = new ArrayList<>();
        intList.add(1);
        intList.add(2);
        intList.add(3);

        List<Double> doubleList = new ArrayList<>();
        doubleList.add(1.1);
        doubleList.add(1.2);
        doubleList.add(1.3);

        List<String> stringList = new ArrayList<>();
        stringList.add("one");
        stringList.add("two");
        stringList.add("three");

        printElement(intList);
        printElement(doubleList);
        printElement(stringList);
    }
}
